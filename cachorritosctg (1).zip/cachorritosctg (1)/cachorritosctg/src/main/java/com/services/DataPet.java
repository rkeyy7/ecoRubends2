package com.services;

public interface DataPet {

}

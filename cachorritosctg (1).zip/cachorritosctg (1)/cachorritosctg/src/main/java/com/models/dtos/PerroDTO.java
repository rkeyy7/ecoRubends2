package com.models.dtos;

public class PerroDTO {

}

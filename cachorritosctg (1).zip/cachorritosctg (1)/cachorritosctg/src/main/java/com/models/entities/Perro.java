package com.models.entities;

public class Perro {
    
}

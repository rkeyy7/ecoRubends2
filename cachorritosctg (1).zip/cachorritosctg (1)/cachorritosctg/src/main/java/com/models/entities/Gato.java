package com.models.entities;

public class Gato {
    
}
